
import {Button} from './components/ui/button';
//import {Chart} from './components/ui/chart';
//<Chart/>
import {Home} from './home';

function App() { 

  return (
    <>
      
<Home/>
    </>
  )
}

export default App
