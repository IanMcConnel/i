import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Accordion,AccordionContent, AccordionItem, AccordionTrigger,
       } from "@/components/ui/accordion"
import { Zap, LineChart, Users } from 'lucide-react'
import { ContactForm } from "./contact-form"
import { Navigation } from "./navigation"
import React from "react"

export function Home() {
  return (
    <div className="min-h-screen bg-[#111] text-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative py-20 text-center px-4">
        <div 
          className="absolute inset-0 z-[-1] bg-[#111]"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 0, 0, 0.85), rgba(0, 0, 0, 0.85)),
              linear-gradient(rgba(17, 17, 17, 0.8), rgba(17, 17, 17, 0.8)),
              repeating-linear-gradient(0deg, transparent, transparent 1px, rgba(255, 255, 255, 0.03) 1px, rgba(255, 255, 255, 0.03) 2px),
              repeating-linear-gradient(90deg, transparent, transparent 1px, rgba(255, 255, 255, 0.03) 1px, rgba(255, 255, 255, 0.03) 2px)
            `,
            backgroundSize: '100% 100%, 100% 100%, 20px 20px, 20px 20px'
          }}
        />
        <div className="relative z-10">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="text-yellow-400">L</span>earn, Build, Grow with AI
          </h1>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            We help you discover, build and launch AI apps and solutions for your team, clients and customers.
          </p>
          <Button className="bg-yellow-400 hover:bg-yellow-500 text-black">Get in Touch</Button>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4" id="solutions">
        <h2 className="text-3xl font-bold text-center mb-12">Our AI Solutions</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card className="bg-[#1a1a1a] border-gray-800">
            <CardContent className="pt-6">
              <div className="rounded-full bg-yellow-400/10 w-12 h-12 flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-yellow-400" />
              </div>
              <h3 className="text-xl font-bold mb-2">AI App Development</h3>
              <p className="text-gray-400">
                Create cutting-edge AI applications tailored to your business needs and industry requirements.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#1a1a1a] border-gray-800">
            <CardContent className="pt-6">
              <div className="rounded-full bg-yellow-400/10 w-12 h-12 flex items-center justify-center mb-4">
                <LineChart className="w-6 h-6 text-yellow-400" />
              </div>
              <h3 className="text-xl font-bold mb-2">AI Process Automation</h3>
              <p className="text-gray-400">
                Streamline your operations with intelligent AI-driven automation solutions for increased efficiency.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#1a1a1a] border-gray-800">
            <CardContent className="pt-6">
              <div className="rounded-full bg-yellow-400/10 w-12 h-12 flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-yellow-400" />
              </div>
              <h3 className="text-xl font-bold mb-2">AI Enterprise Training</h3>
              <p className="text-gray-400">
                Empower your team with comprehensive training programs tailored for enterprise-level implementation.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-4 bg-[#1a1a1a]" id="about">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-yellow-400">About Us</h2>
          <p className="text-gray-300 mb-6">
            At Switch Dimension, we're passionate about leveraging the power of AI to transform businesses. Our team of expert data scientists and engineers work tirelessly to develop cutting-edge AI solutions that drive real-world results.
          </p>
          <p className="text-gray-300">
            With years of experience across various industries, we understand the unique challenges businesses face and tailor our AI solutions to meet your specific needs. Our mission is to make AI accessible and impactful for businesses of all sizes.
          </p>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 px-4" id="testimonials">
        <h2 className="text-3xl font-bold text-center mb-12">What Our Clients Say</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card className="bg-[#1a1a1a] border-gray-800">
            <CardContent className="pt-6">
              <p className="text-gray-300 mb-4">
                "Switch Dimension transformed our business with their AI solutions. We've seen a 40% increase in efficiency."
              </p>
              <p className="text-yellow-400 font-semibold">Sarah Johnson</p>
              <p className="text-sm text-gray-500">TechCorp</p>
            </CardContent>
          </Card>

          <Card className="bg-[#1a1a1a] border-gray-800">
            <CardContent className="pt-6">
              <p className="text-gray-300 mb-4">
                "The predictive analytics tool from Switch Dimension has revolutionized our decision-making process."
              </p>
              <p className="text-yellow-400 font-semibold">Michael Chen</p>
              <p className="text-sm text-gray-500">InnovateX</p>
            </CardContent>
          </Card>

          <Card className="bg-[#1a1a1a] border-gray-800">
            <CardContent className="pt-6">
              <p className="text-gray-300 mb-4">
                "Working with Switch Dimension was a game-changer. Their AI expertise is unmatched in the industry."
              </p>
              <p className="text-yellow-400 font-semibold">Emily Rodriguez</p>
              <p className="text-sm text-gray-500">FutureTech</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4 bg-[#1a1a1a]" id="faq">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="w-full bg-[#1a1a1a]">
            <AccordionItem value="item-1" className="border-gray-800 bg-[#1a1a1a]">
              <AccordionTrigger className="text-left bg-[#1a1a1a]">What industries do you serve?</AccordionTrigger>
              <AccordionContent className="text-gray-400 bg-[#1a1a1a]">
                We serve a wide range of industries including healthcare, finance, retail, manufacturing, and technology sectors.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2" className="border-[#1a1a1a] bg-[#1a1a1a]">
              <AccordionTrigger className="text-left bg-[#1a1a1a]">How long does it take to implement your AI solutions?</AccordionTrigger>
              <AccordionContent className="text-gray-400 bg-[#1a1a1a]">
                Implementation timelines vary based on project complexity, typically ranging from 2-6 months.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3" className="border-gray-800 bg-[#1a1a1a]">
              <AccordionTrigger className="text-left bg-[#1a1a1a]">Do I need to have technical expertise to use your services?</AccordionTrigger>
              <AccordionContent className="text-gray-400 bg-[#1a1a1a]">
                No technical expertise is required. We handle all technical aspects while ensuring you can easily use and manage the solutions.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4" className="border-gray-800 bg-[#1a1a1a]">
              <AccordionTrigger className="text-left bg-[#1a1a1a]">How do you ensure data privacy and security?</AccordionTrigger>
              <AccordionContent className="text-gray-400 bg-[#1a1a1a]">
                We implement industry-standard security protocols and comply with all relevant data protection regulations.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 px-4" id="contact">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-8">Get in Touch</h2>
          <p className="text-gray-400 mb-8">
            Ready to start your AI journey? Contact us to discuss how we can help transform your business.
          </p>
          <ContactForm />
        </div>
      </section>
    </div>
  )
}

