"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import React from "react"

export function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)
    // Add your form submission logic here
    await new Promise(resolve => setTimeout(resolve, 1000))
    setIsSubmitting(false)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <Input
          type="text"
          placeholder="Your Name"
          required
          className="bg-[#1a1a1a] border-gray-800 text-white placeholder:text-gray-500"
        />
      </div>
      <div>
        <Input
          type="email"
          placeholder="Your Email"
          required
          className="bg-[#1a1a1a] border-gray-800 text-white placeholder:text-gray-500"
        />
      </div>
      <div>
        <Textarea
          placeholder="Your Message"
          required
          className="bg-[#1a1a1a] border-gray-800 text-white placeholder:text-gray-500 min-h-[120px]"
        />
      </div>
      <Button
        type="submit"
        className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-semibold"
        disabled={isSubmitting}
      >
        {isSubmitting ? "Sending..." : "Send Message"}
      </Button>
    </form>
  )
}

