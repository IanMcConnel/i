

npx watch 'npm run build'

