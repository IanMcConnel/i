
import {Button} from './components/ui/button';
//import {Chart} from './components/ui/chart';
//<Chart/>

function App() { 

  return (
    <>
      
      <div className='bg-[grey] px-[20px] p-[5px]'>
         <Button>PARTY</Button>
      </div>
    </>
  )
}

export default App
